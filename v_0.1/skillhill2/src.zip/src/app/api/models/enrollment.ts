export class Enrollment{
    enrollment_id?: number;
    user_id?: string;
    course_id?: number;
    enrollment_date?: Date;
}