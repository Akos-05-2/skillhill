export class User{
    id?: string;
    name?: string;
    username?: string;
    email?: string;
    emailVerified?: Date;
    image?: string;
    createdAt?: Date;
    updatedAt?: Date;
    role?: string;
}