export interface ICourse{
    course_id?: number;
    course_name?: string;
    description?: string;
}