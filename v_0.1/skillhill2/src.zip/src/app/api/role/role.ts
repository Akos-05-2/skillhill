import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { OPTIONS } from "../auth/[...nextauth]/route";

export enum Role{
    ADMIN = 'ADMIN',
    TEACHER = 'TEACHER',
    USER = 'USER',
    GUEST = 'GUEST'
}

export async function GET(){
    const session = await getServerSession(OPTIONS);
    console.log(session);
    try{
        
    }catch{
        console.error('Hiba a felhasználó keresése többen!');
        return NextResponse.json({error: 'Hiba a csatlakozás során!'}, {status: 500});
    }
}