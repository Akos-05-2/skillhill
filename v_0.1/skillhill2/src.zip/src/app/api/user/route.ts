import { OPTIONS, prisma } from '../auth/[...nextauth]/route';
import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';

export async function DELETE(req: Request) {  
     const session = await getServerSession(OPTIONS);
     console.log(session);
     const {email} = await req.json();
     const user = await prisma.user.delete({
         where: {email: email},
     });
     return NextResponse.json(JSON.stringify(user), {status: 200});
}

// export async function GETBYEMAIL(req: Request) {
//     const session = await getServerSession(OPTIONS);
//     console.log(session);
//     const url = new URL(req.url);
//     const email = url.searchParams.get('email');
//     if (!email) {
//         return NextResponse.json({ error: 'Szükséges az email megadása!' }, { status: 400 });
//     }
//     try {
//         const user = await prisma.user.findUnique({
//             where: { email: email },
//         });
//         if (!user) {
//             return NextResponse.json({ error: 'Nem található felhastználó!' }, { status: 404 });
//         }
//         const createdAt = user.createdAt;
//         console.log(email, createdAt);
//         return NextResponse.json(user, { status: 200 });
//     } catch{
//         console.error('Hiba a felhasználó keresése közben!');
//         return NextResponse.json({ error: 'Hiba a csatlakozás során!' }, { status: 500 });
//     }
// }

// export async function GET(){
//     const session = await getServerSession(OPTIONS);
//     console.log(session);
//     try{
//         const users = await prisma.user.findMany();
//         console.log(users);
//         return NextResponse.json(users, {status: 200});
//     }catch{
//         console.error('Hiba a cstlakozás során!');
//         return NextResponse.json({error: 'Hiba a csatlakozás során!'}, {status: 500});
//     }
//}

export async function GET(){
    const session = await getServerSession(OPTIONS);
    console.log(session);
    try{
        const email = session?.user?.email;
        const user = await prisma.user.findUnique({
            where: {email: email ?? ""},
            select: {
                id: false,
                email: true,
                name: true,
                createdAt: true,
                image: true
            }
        });
        if(!user){
            return NextResponse.json({error: 'Nem található felhasználó!'}, {status: 404});
        }
        return NextResponse.json(user, {status: 200});
    }catch{
        console.error('Hiba a felhasználó keresése többen!');
        return NextResponse.json({error: 'Hiba a csatlakozás során!'}, {status: 500});
    }
}