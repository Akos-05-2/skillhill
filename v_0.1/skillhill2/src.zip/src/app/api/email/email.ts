import nodemailer from 'nodemailer';
import dotenv from 'dotenv';
import crypto from 'crypto';
dotenv.config();

const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASSWORD,
    },
});

export const generateVerificationToken = () =>{
    return crypto.randomBytes(32).toString('hex');
}

export const createVerificationLink = (baseURL: string, token: string) => {
    return `${baseURL}/api/verify?token=${token}`
}

export const sendEmail = async (to: string, verifitacionLink: string) => {
    const mailOptions = {
        from: process.env.EMAIL_USER,
        to: to,
        subject: 'Kérjük erősítse meg email címét!',
        text: `Kérjük kattintson az alábbi linkre a fiókja megjelenítéséhez: ${verifitacionLink}`,
        html: `<p>Kérjük kattintson az alábbi linkre a fiókja megerősítéséhez: <p><a href=${verifitacionLink}>${verifitacionLink}</></p></p>`,
    };
    try{
        await transporter.sendMail(mailOptions);
        console.log('SIkeresen elküldött email!');
    }catch{
        console.error('Hiba történt a küldésor!');
    }
}