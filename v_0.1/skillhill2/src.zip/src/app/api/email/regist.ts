import { NextApiRequest, NextApiResponse } from 'next';
import {sendEmail} from './email';
import {createVerificationLink, generateVerificationToken} from './email';

export default async function handler(req: NextApiRequest, res: NextApiResponse){
    if(req.method === 'POST'){
        const {email} = req.body;
        const token = generateVerificationToken();
        const verifiyLink = createVerificationLink('http://localhost:3000/verify', token);
        await sendEmail(email, verifiyLink);
        res.status(200).json({success: true});
    }
    else{
        res.setHeader('Allow', 'POST');
        res.status(405).send(`A(z) ${req.method} metódus nem engedélyezett!`);
    }
}