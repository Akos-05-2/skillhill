import { PrismaAdapter } from "@next-auth/prisma-adapter";
import { PrismaClient } from "@prisma/client";
import NextAuth from "next-auth";
import GoogleProvider from "next-auth/providers/google";
import DiscordProvider from "next-auth/providers/discord";
import SpotifyProvider from "next-auth/providers/spotify";

export const prisma = new PrismaClient()
const env = process.env;
export const OPTIONS = {
  providers: [
    GoogleProvider({
      clientId: env.GOOGLE_ID as string,
      clientSecret: env.GOOGLE_SECRET as string,
    }),
    DiscordProvider({
      clientId: env.DISCORD_ID as string,
      clientSecret: env.DISCORD_SECRET as string,
      token: 'https://discord.com/api/oauth2/token',
      authorization: {
        url: 'https://discord.com/api/oauth2/authorize',
        params: {redirect_uri: 'http://localhost:3000/api/auth/callback/discord'}
      }
    }),
    SpotifyProvider({
      clientId: env.SPOTIFY_ID as string,
      clientSecret: env.SPOTIFY_SECRET as string,
      token: 'https://accounts.spotify.com/api/token',
      authorization: {
        url: 'https://accounts.spotify.com/authorize',
        params: {redirect_uri: 'http://localhost:3000/api/auth/callback/spotify'}
      }
    })
  ],
  adapter: PrismaAdapter(prisma),
  debug: true
};

const handler = NextAuth(OPTIONS);
export { handler as GET, handler as POST };