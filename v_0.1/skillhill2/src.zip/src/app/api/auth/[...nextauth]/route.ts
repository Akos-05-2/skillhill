import { PrismaAdapter } from "@next-auth/prisma-adapter";
import { PrismaClient } from "@prisma/client";
import NextAuth from "next-auth";
import GoogleProvider from "next-auth/providers/google";

export const prisma = new PrismaClient()

export const OPTIONS = {
  providers: [
    GoogleProvider({
      clientId: process.env.GOOGLE_ID as string,
      clientSecret: process.env.GOOGLE_SECRET as string,
    }),

  ],
  adapter: PrismaAdapter(prisma),
};

const handler = NextAuth(OPTIONS);
export { handler as GET, handler as POST };