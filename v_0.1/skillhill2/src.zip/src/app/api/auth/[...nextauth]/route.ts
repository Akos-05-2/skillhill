import { PrismaAdapter } from "@next-auth/prisma-adapter";
import { PrismaClient } from "@prisma/client";
import GoogleProvider from "next-auth/providers/google";
import DiscordProvider from "next-auth/providers/discord";
import SpotifyProvider from "next-auth/providers/spotify";
import NextAuth from "next-auth";

export const prisma = new PrismaClient()
export const OPTIONS = {
  providers: [
    GoogleProvider({
      clientId: process.env.GOOGLE_ID as string,
      clientSecret: process.env.GOOGLE_SECRET as string,
    }),
    DiscordProvider({
      clientId: process.env.DISCORD_ID as string,
      clientSecret: process.env.DISCORD_SECRET as string,
      token: 'https://discord.com/api/oauth2/token',
      authorization: {
        url: 'https://discord.com/api/oauth2/authorize',
        params: {redirect_uri: 'http://localhost:3000/api/auth/callback/discord'}
      }
    }),
    SpotifyProvider({
      clientId: process.env.SPOTIFY_ID as string,
      clientSecret: process.env.SPOTIFY_SECRET as string,
      token: 'https://accounts.spotify.com/api/token',
      authorization: {
        url: 'https://accounts.spotify.com/authorize',
        params: {redirect_uri: 'http://localhost:3000/api/auth/callback/spotify'}
      }
    })
  ],
  adapter: PrismaAdapter(prisma),
  debug: true,
  // callbacks: {
  //  async session({session, token}: {session: {user: {id: string, role: string}}}, {token: JWT}) {
  //     session.user.id = token.id;
  //     session.user.role = token.role;
  //     return session;
  //  } 
  // }
}

const handler = NextAuth(OPTIONS);
export { handler as GET, handler as POST };