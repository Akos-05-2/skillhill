import {OPTIONS, prisma} from '../auth/[...nextauth]/route';
import {NextResponse} from 'next/server';
import NextAuth from 'next-auth';

export async function GET(){
    const session = await NextAuth(OPTIONS);
    if (!session){
        return NextResponse.json({error: 'Nem található felhasználó!'}, {status: 404});
    }
    try{
        const courses = await prisma.courses.findMany({
            select: {
                course_id: false,
                course_name: true,
                description: true
            }
        });
        return NextResponse.json(courses, {status: 200});
    }catch{
        console.error('Hiba a csatlakozás során!');
        return NextResponse.json({error: 'Hiba a csatlakozás során!'}, {status: 500});
    }
}