export enum Role{
    ADMIN = 'ADMIN',
    TEACHER = 'TEACHER',
    USER = 'USER',
    GUEST = 'GUEST'
}