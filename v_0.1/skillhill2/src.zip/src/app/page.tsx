"use client";

import React, {useEffect, useState} from 'react';
import LogOut from './logout/page';
function apiCall(): Promise<string> {
  return fetch('http://localhost:3000/api/user', {
    method: 'GET'
  })
  .then(response => response.text());
}

export default function Home() {
  const [data, setData] = useState<string>('');

  useEffect(() => {
    apiCall().then(result => setData(result));
  }, []);

  return (
    <div>
      <p>
        {data}
      </p>
      <LogOut/>
    </div>
  );
}

