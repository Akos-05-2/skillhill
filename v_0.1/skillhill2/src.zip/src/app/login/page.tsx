"use client";
import './page.css';
import { signIn } from "next-auth/react";
import Image from 'next/image';

export default function Login() {

  const handleSignIn = async () => {
    try {
      await signIn('google');
      window.location.href='http://localhost:3000';
    } catch (error) {
      console.error('Error signing in', error);
    }
  };

  return (
    <div>
      <button onClick={handleSignIn}>Login with Google<Image src="https://authjs.dev/img/providers/google.svg" width={30} height={30} alt="Google logo" /></button>
    </div>
  );
}