"use client";
import { SessionProvider } from "next-auth/react";
import './page.css';
import Image from 'next/image';
import { signIn, useSession } from "next-auth/react";
export default function Login() {
  return (
    <SessionProvider>
      <LoginInner />
    </SessionProvider>
  );
}

function LoginInner() {
  const { data: session, status } = useSession();

  const handleSignIn = async () => {
    try {
      await signIn('google', { redirect: true });
      if (status === 'authenticated') {
        window.location.href = 'http://localhost:3000';
        return;
      }
    } catch (error) {
      console.error('Error signing in', error);
    }
  };

  return (
    <div>
      <button onClick={handleSignIn}>
        Login with Google
        <Image src="https://authjs.dev/img/providers/google.svg" width={30} height={30} alt="Google logo" />
      </button>
    </div>
  );
}