"use client";
import { SessionProvider } from "next-auth/react";
import './page.css';
import Image from 'next/image';
import { signIn, useSession } from "next-auth/react";
export default function Login() {
  return (
    <SessionProvider>
      <LoginInner />
    </SessionProvider>
  );
}

function LoginInner() {
  const { data: session, status } = useSession();
  console.log(session);
  const handleSignIn = async () => {
    try {
      await signIn('google', { redirect: true });
      if (status === 'authenticated') {
        window.location.href = 'http://localhost:3000';
        return;
      }
    } catch (error) {
      console.error('Error signing in', error);
    }
  };
  
    const handleSignInDiscord = async () => {
      try {
        await signIn('discord', { redirect: true });
        if (status === 'authenticated') {
          window.location.href = 'http://localhost:3000';
          return;
        }
      } catch (error) {
        console.error('Error signing in', error);
      }
    };
  
    const handleSignInSpotify = async () => {
      try {
        await signIn('spotify', { redirect: true });
        if (status === 'authenticated') {
          window.location.href = 'http://localhost:3000';
          return;
        }
      } catch (error) {
        console.error('Error signing in', error);
      }
  
    }
    return (
      <div id="login">
        <button onClick={handleSignIn}>
            Login with Google
            <Image src="https://authjs.dev/img/providers/google.svg" width={30} height={30} alt="Google logo" />
          </button>
          <button onClick={handleSignInDiscord}>
            Login with Discord
            <Image src="https://authjs.dev/img/providers/discord.svg" width={30} height={30} alt="Twitch logo" />
          </button>
          <button onClick={handleSignInSpotify}>
            Login with Spotify
            <Image src="https://authjs.dev/img/providers/spotify.svg" width={30} height={30} alt="Discord logo" />
          </button>
      </div>
        );
}