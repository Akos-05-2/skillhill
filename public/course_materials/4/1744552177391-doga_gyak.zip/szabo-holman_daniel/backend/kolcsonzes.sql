CREATE DATABASE kolcsonzes;

use kolcsonzes;

CREATE TABLE berlok(
    id INT PRIMARY KEY AUTO_INCREMENT,
    nev VARCHAR(100) NOT NULL,
    jogositvany VARCHAR(15) NOT NULL,
    email VARCHAR(30) UNIQUE NOT NULL,
    jelszo BLOB NOT NULL,
    telefonszam VARCHAR(20)
);

CREATE TABLE autok(
    id INT PRIMARY KEY AUTO_INCREMENT,
    rendszam VARCHAR(7) UNIQUE NOT NULL,
    tipus VARCHAR(100) NOT NULL,
    evjarat INT,
    szin VARCHAR(20)
);

CREATE TABLE kolcsonzes(
    id INT PRIMARY KEY AUTO_INCREMENT,
    berloid INT NOT NULL,
    autoid INT NOT NULL,
    berletkezdete DATETIME NOT NULL,
    napokszama INT,
    napidij INT NOT NULL,
    FOREIGN KEY (berloid) REFERENCES berlok(id),
    FOREIGN KEY (autoid) REFERENCES autok(id)
);

DELIMITER $$

CREATE TRIGGER AutoInsert
BEFORE INSERT
ON autok
FOR EACH ROW
SET NEW.rendszam = UPPER(NEW.rendszam)$$

CREATE TRIGGER BerloInsert
BEFORE INSERT
ON berlok
FOR EACH ROW
SET NEW.jelszo = EncryptPassword(NEW.jelszo)$$



CREATE FUNCTION LogIn(email VARCHAR(30), jelszo VARCHAR(256))
RETURNS INT
BEGIN
IF (SELECT berlok.id FROM berlok WHERE berlok.email = email AND berlok.jelszo = EncryptPassword(jelszo)) > 0 THEN
    RETURN (SELECT berlok.id FROM berlok WHERE berlok.email = email AND berlok.jelszo = EncryptPassword(jelszo));
ELSE
    RETURN 0;
END IF;
END$$

CREATE FUNCTION EncryptPassword(jelszo VARCHAR(256))
RETURNS BLOB
BEGIN
RETURN SHA2(CONCAT(jelszo, "sozas"), 256);
END$$

DELIMITER ;

INSERT INTO berlok(nev, jogositvany, telefonszam, email, jelszo) VALUES ("Kandúr Károly", "LR123456", "0622354784", "Kandi@kandi.hu", "Titok123");
INSERT INTO berlok(nev, jogositvany, telefonszam, email, jelszo) VALUES ("Gipsz Jakab", "VE566666", "06305248787", "Gipsz@gipsz.hu", "Titok123");

INSERT INTO autok(rendszam, tipus, evjarat, szin) VALUES("AALA475", "Ford Ka", 2005, "Szürke");
INSERT INTO autok(rendszam, tipus, evjarat, szin) VALUES("ABC123", "VW Golf", 2022, "Fehér");
INSERT INTO autok(rendszam, tipus, evjarat, szin) VALUES("AAJQ625", "Ford Mondeo", 2021, "Kék");
INSERT INTO autok(rendszam, tipus, evjarat, szin) VALUES("AADD596", "Seat Toledo", 2008, "Zöld");