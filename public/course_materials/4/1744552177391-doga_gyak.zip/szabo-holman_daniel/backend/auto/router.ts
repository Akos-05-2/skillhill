import { Router } from "express";
import { GetAutok, GetAutoById, CreateAuto, UpdateAuto } from "./auto_model";

const router = Router();

router.get("/", GetAutok);
router.get("/:id", GetAutoById);
router.post("/", CreateAuto);
router.put("/:id", UpdateAuto);

export default router;