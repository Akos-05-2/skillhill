import { Request, Response } from "express";
import mysqlP from "mysql2/promise";
import dbConfig from "../app/config";

export interface IAuto{
    id?: number,
    tipus?: string,
    rendszam?: string,
    evjarat?: number,
    szin?: string
}

export class Auto implements IAuto{
    id?: number
    tipus?: string
    rendszam?: string
    evjarat?: number
    szin?: string

    static async GetAutok(){
        try{
            const conn = await mysqlP.createConnection(dbConfig);
            const autok = await conn.query("SELECT * FROM autok;");
            return autok[0];
        }
        catch(err){
            console.log(err);
        }
    }

    static async GetAutoById(autoid: number){
        try{
            const conn = await mysqlP.createConnection(dbConfig);
            const autok = await conn.query("SELECT * FROM autok WHERE autok.id = ?;", [autoid]);
            return autok[0];
        }
        catch(err){
            console.log(err);
        }
    }

    static async CreateAuto(auto: Auto){
        try{
            const conn = await mysqlP.createConnection(dbConfig);
            await conn.query("INSERT INTO autok (tipus, rendszam, evjarat, szin) VALUES(?, ?, ?, ?);", [auto.tipus, auto.rendszam, auto.evjarat, auto.szin]);
            const lastinsertid = await conn.query("SELECT LAST_INSERT_ID();");
            return lastinsertid;
        }
        catch(err){
            console.log(err);
        }
    }

    static async UpdateAuto(auto: Auto){
        try{
            const conn = await mysqlP.createConnection(dbConfig);
            const result = await conn.query("UPDATE autok SET autok.rendszam = ?, autok.tipus = ?, autok.evjarat = ?, autok.szin = ? WHERE autok.id = ?;", [auto.rendszam, auto.tipus, auto.evjarat, auto.szin, auto.id]);
            console.log(result);
            return result;
        }
        catch(err){
            console.log(err);
        }
    }
}