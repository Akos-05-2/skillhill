import { Request, Response } from "express";
import mysqlP from "mysql2/promise";
import dbConfig from "../app/config";
import dotenv from "dotenv";
import jwt from "jsonwebtoken";
import {Auto} from "./auto";
import { executionAsyncResource } from "async_hooks";

export async function GetAutok(req: Request, res: Response){
    const autok = await Auto.GetAutok();
    res.status(200).send(autok);
    return;
}

export async function GetAutoById(req: Request, res: Response){
    const autoid = req.params.id;
    if(!autoid){
        res.status(400).send("Az adatok nem megfelelőek!");
        return;
    }

    const autok = await Auto.GetAutoById(parseInt(autoid));

    res.status(200).send(autok);
    return;
}

export async function CreateAuto(req: Request, res: Response){
    const auto = new Auto();
    auto.tipus = req.body.tipus;
    auto.rendszam = req.body.rendszam;
    auto.evjarat = req.body.evjarat;
    auto.szin = req.body.szin;
    if(!auto.tipus || !auto.rendszam){
        res.status(400).send("Az adatok nem megfelelőek!");
        return;
    }

    const id = await Auto.CreateAuto(auto);

    res.status(201).send(id);
    return;
}

export async function UpdateAuto(req: Request, res: Response){
    const row: any = await Auto.GetAutoById(parseInt(req.params.id));
    const auto = row[0];

    if(!auto.tipus && !auto.rendszam && auto.evjarat && !auto.szin){
        res.status(400).send("Az adatok nem megfelelőek!");
        return;
    }

    if(!auto){
        res.status(404).send("Az elem nem létezik!");
    }

    if(req.body.tipus){
        auto.tipus = req.body.tipus;
    }


    if(req.body.rendszam){

        auto.rendszam = req.body.rendszam;
    }

    if(req.body.evjarat){

        auto.evjarat = parseInt(req.body.evjarat);
    }

    if(req.body.szin){

        auto.szin = req.body.szin;
    }

    const result = await Auto.UpdateAuto(auto);

    console.log(result);

    if(!result){
        res.status(404).send("Nem módosult!");
    }

    res.status(201).send("Sikeres módosítás!");
    return;
}