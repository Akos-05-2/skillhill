import express from "express";
import loginRouter from "../login/router";
import autoRouter from "../auto/router";

const app = express();

app.use(express.json());

app.use("/api/login", loginRouter);
app.use("/api/auto", autoRouter);

export default app;