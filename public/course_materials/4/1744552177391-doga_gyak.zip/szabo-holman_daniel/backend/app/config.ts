import dotenv from "dotenv";

dotenv.config();

const {DBUSER, DBPASS, DATABASE, DBHOST} = process.env;

class mySqlConfig{
    user?: string = DBUSER
    password?: string = DBPASS
    database?: string = DATABASE
    host?: string = DBHOST
    constructor(){
        return {user: this.user, password: this.password, database: this.database, host: this.host};
    }
}

const dbConfig = new mySqlConfig();

export default dbConfig;