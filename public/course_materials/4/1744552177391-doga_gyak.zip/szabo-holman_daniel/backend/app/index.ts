import app from "./app";
import dotenv from "dotenv";
import { Request, Response } from "express";

dotenv.config();

app.get("/", (req, res) => {
    res.status(200).send("A szerver fut");
    return;
});

const {PORT} = process.env;

app.listen(PORT, () => {
    console.log(`A szerver fut a következő porton: ${PORT}`);
});