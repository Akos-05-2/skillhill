import { Request, Response } from "express";
import mysqlP from "mysql2/promise";
import dbConfig from "../app/config";
import dotenv from "dotenv";
import jwt from "jsonwebtoken";

dotenv.config();

export default async function LogIn(req: Request, res: Response){
    const email = req.body.email;
    const password = req.body.password;

    if(!email || !password){
        res.status(404).send("Hiányzó paraméter!");
    }

    const conn = await mysqlP.createConnection(dbConfig);

    const [rows]: any = await conn.query("SELECT LogIn(?, ?) AS userid", [email, password]);
    if(!rows.userid){
        res.status(401).send("Hibás email vagy jelszó!");
        return;
    }

    const {JWT_STRING} = process.env;
    if(!JWT_STRING){
        res.send(500).send("Hiba a token generálásakor!");
        return;
    }

    const payload = {userid: rows.userid};
    const token = jwt.sign(payload, JWT_STRING, {expiresIn: "2h"});
    res.status(200).send({token: token});
}