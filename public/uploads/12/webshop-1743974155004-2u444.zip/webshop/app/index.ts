import app from './app'

import productRouter from '../produts/router';
import userRouter from '../user/router'
import loginRouter from '../login/router';
import orderRouter from '../order/router';

app.use(productRouter)
app.use('/api', userRouter)
app.use('/api', orderRouter)
app.use('/api', productRouter)
app.use(loginRouter)

app.listen(3008, () => {
    console.log('Fut a szerver');
});