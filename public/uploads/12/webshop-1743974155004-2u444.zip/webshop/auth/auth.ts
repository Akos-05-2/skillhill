import jwt from 'jsonwebtoken';
import dotenv from 'dotenv'
import {Request, Response} from 'express'

dotenv.config();

export default function verifyToken(req: any, res: any, next: any){
    const token = req.headers.authorization?.split(' ')[1];
    if (!token){
        res.status(401).send({error: 'Token kell'})
        return;
    }

    const {JWT_TOKEN} = process.env;
    if (!JWT_TOKEN){
        res.status(401).send({error: 'Hiba'})
        return;
    }

    try{
        const decodedToken  = jwt.verify(token, JWT_TOKEN);
        req.decodedToken = decodedToken;
        next();
    }
    catch{
        res.status(401).send('Hibás token!')
        return;
    }
}