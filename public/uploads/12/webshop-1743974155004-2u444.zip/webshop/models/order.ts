import { connect } from '../config/config';

interface IOrder{
    orderid?: number;
    userid?: number;
    date?: Date;
}

export class Order implements IOrder{
    orderid?: number;
    userid?: number;
    date?: Date;
}