import { connect } from '../config/config';

interface IUser{
    uid?: number;
    name?: string;
    email?: string;
    password?: string;
    address?: string;
    token?: string | null;
}

export class User implements IUser{
    uid?: number;
    name?: string;
    email?: string;
    password?: string;
    address?: string;
    token?: string | null;

    async loadDataFromDB(uid : number) : Promise<boolean> {
        try {
            const conn = await connect
            const rows: any =  await conn.query('SELECT * from user WHERE uid = ?', [uid], (err, result: any, fields) => {
                Object.assign(this,result[0])
            })
            
            return true
        }
        catch {
            return false
        }
    }

    static async validUser(email: string, password: string) {
        try {
            const conn = await connect;
            const [rows]: any = conn.query('SELECT * FROM user WHERE user.email = ? and user.password = SHA2(?, 256)', [email, password]);
            return rows[0];
        } catch (err) {
            console.log(err);
            return null;  
        }
    }
    
}