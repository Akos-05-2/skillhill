import { Router } from 'express'
import logIn from './login-model';

const loginRouter = Router();

loginRouter.post('/login', logIn)

export default loginRouter