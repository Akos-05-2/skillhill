import { User } from "../models/user";
import { Request, Response } from 'express';
import dotenv from 'dotenv';
import jwt from 'jsonwebtoken';
import { connect } from "../config/config";
dotenv.config();

export default async function logIn(req: Request, res: Response){
    const user: User = new User();
    Object.assign(user, req.body);
    if(!user.email || !user.password){
        res.status(401).send('Hiányos adatok');
        return;
    }

    const UserId = await User.validUser(user.email, user.password)
    if(!UserId) {
        res.status(401).send({error:"Hibás felhasználónév vagy jelszó!"})
    }

    const { JWT_TOKEN } = process.env;
    if (!JWT_TOKEN){
        res.status(401).send('Rossz a token!');
        return;
    }

    const payload = {UserId: user.uid}
    user.token = jwt.sign(payload, JWT_TOKEN)

    res.json({token: user.token});
}