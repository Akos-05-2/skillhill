import { Router } from "express";
import { getProducts } from "./produt-model";
const productRouter = Router();

productRouter.get('/products', getProducts)

export default productRouter