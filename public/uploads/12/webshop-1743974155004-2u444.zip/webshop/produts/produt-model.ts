import { Request, Response } from "express";
import mysql from 'mysql'
import { connect } from "../config/config";

export async function getProducts(req: any, res: Response) {
    const conn = await connect;
    const rows: any = await conn.query(
      "SELECT * from products",
      (err, result: any, fields) => {
        const product = result;
        res.json({product});
      }
    );
  }