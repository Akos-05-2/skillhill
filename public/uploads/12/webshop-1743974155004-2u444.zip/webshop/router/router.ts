import  express, {Router} from "express"
const router:Router = express.Router()
export default router