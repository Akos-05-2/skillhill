import { Router } from 'express'
import { getUserFromId, newUser } from './user-model';
import auth from '../auth/auth'
const userRouter = Router();

userRouter.get('/user', auth, getUserFromId)
userRouter.post('/user', newUser)

export default userRouter