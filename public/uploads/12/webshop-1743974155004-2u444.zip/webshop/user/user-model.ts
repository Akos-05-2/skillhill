import { Request, Response } from "express";
import { User } from "../models/user";
import { connect } from "../config/config";

export async function getUserFromId(req: any, res: Response) {
  if (!req.decodedToken.uid) {
    res.status(401).send({ error: "Hiányzó felhasználó azonosító" });
    return;
  }
  const conn = await connect;
  const rows: any = await conn.query(
    "SELECT * from user WHERE uid = ?",
    [req.decodedToken.uid],
    (err, result: any, fields) => {
      const user = result[0];

      if (!user.email) {
        res.status(404).send({ error: "Nem létező felhasználó" });
        return;
      }
      res.json({name: user.name, address: user.address, emal: user.email});
    }
  );
}

export async function newUser(req: any, res: any){
  const {name, email, password, address} = req.body;
  const conn = await connect;
  const rows: any = await conn.query(
    "INSERT INTO user (uid, name, email, password, address) VALUES (null, ?, ?, ?, ?)",
    [name, email, password, address],
    (err, result: any, fields) => {
      const user = result;
      res.json({name: name, address: address, emal: email});
    }
  );

}