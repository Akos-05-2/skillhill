import { Router } from 'express'
import { newOrder } from './order-model';
import auth from '../auth/auth'

const orderRouter = Router();

orderRouter.post('/order', auth, newOrder);

export default orderRouter