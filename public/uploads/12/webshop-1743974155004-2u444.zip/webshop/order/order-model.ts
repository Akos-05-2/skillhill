import { Request, Response } from 'express'
import { connect } from '../config/config';
import { Order } from '../models/order';

export async function newOrder(req: any, res: any){
  const { userid, date, products } = req.body;
  const conn = await connect;
  const rows: any = await conn.query(
    "INSERT INTO orders (orderid, userid, date, products) VALUES (null, ?, ?, ?)",
    [userid, date, products],
    (err, result: any, fields) => {
      const order = result;
      res.json({id: order});
    }
  );

}