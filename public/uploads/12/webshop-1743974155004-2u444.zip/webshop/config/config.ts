import mysql from 'mysql'

export const connect = mysql.createPool({
    host: 'localhost',
    password: '',
    database: 'webshop',
    user: 'root'
})