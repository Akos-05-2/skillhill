import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import { Route, RouterProvider, createBrowserRouter } from 'react-router-dom'

import 'bootstrap/dist/css/bootstrap.min.css'
import './index.css'
import Nyitooldal from './components/nyitooldal'
import Kutyak from './components/kutyak'
import UjKutya from './components/ujkutya'

const router = createBrowserRouter([
  {
    path: '/',
    element: <Nyitooldal />
  },
  {
    path: '/kutyak',
    element: <Kutyak />
  },
  {
    path: '/ujkutya',
    element: <UjKutya />
  },
]);

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <RouterProvider router={router} />
  </StrictMode>,
)
