export interface Kutya{
    id: number,
    nev: string,
    fajta: string,
    nem: boolean,
    eletkor: number,
    kepUrl: string
}