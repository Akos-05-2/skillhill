import { useRef, useState } from "react";
import { useNavigate } from "react-router-dom";

export default function UjKutya() {
  const inputNev = useRef(null);
  const inputFajta = useRef(null);
  const inputNem = useRef(null);
  const inputEletkor = useRef(null);
  const inputKep = useRef(null);

  const navigate = useNavigate()

  const [errorState, setErrorState] = useState(undefined);

  const addNewKutya = async() =>{
    try {

        let eletkor;
        if(inputEletkor.current.value*1 < 0)
            eletkor = 0;
        else if(inputEletkor.current.value*1 > 20)
            eletkor = 20;
        else
            eletkor = inputEletkor.current.value*1;

        const result = await fetch("http://localhost:5000/kutyk", {
            headers: {
                'Content-Type': 'application/json;charset=UTF-8'
            },
            method: "POST",
            body: JSON.stringify({
                "nev": inputNev.current.value,
                "fajta": inputFajta.current.value,
                "nem": inputNem.current.checked?true:false,
                "eletkor": eletkor,
                "kepUrl": inputKep.current.value
            })
        });
        
        if(result.status == 200){
            navigate("/kutyak");
        }
        else{
            throw(result);
        }
         
      } catch (error) {
        console.log(error);
        setErrorState(error);
      }
  }

  return (
    <div className="container">
      <header className="text-center">
        <div className="row my-3">
          <h1>Új kutya felvétele</h1>
        </div>
      </header>
      <main>
        <div className="row">
          <div className="col-md-3"></div>
          <div className="col-md-6">
            
              <label htmlFor="nev" className="form-label mt-2">
                Kutya neve
              </label>
              <input
                ref={inputNev}
                type="text"
                id="nev"
                className="form-control"
              />

              <label htmlFor="fajta" className="form-label mt-2">
                Kutya fajtája
              </label>
              <input
                ref={inputFajta}
                type="text"
                id="fajta"
                className="form-control"
              />

              <div className="mt-3">Kutya neme</div>
              <input
                type="radio"
                id="nem-szuka"
                name="nem"
                className="form-check-input mt-2 ms-3"
              />
              <label htmlFor="nem-szuka" className="form-check-label mt-1 ms-2">
                Szuka
              </label>
              <br />
              <input
                ref={inputNem}
                type="radio"
                id="nem-kan"
                name="nem"
                className="form-check-input mt-2 ms-3"
              />
              <label htmlFor="nem-kan" className="form-check-label mt-1 ms-2">
                Kan
              </label>
              <br />

              <label htmlFor="eletkor" className="form-label mt-2">
                Kutya életkora
              </label>
              <input
                ref={inputEletkor}
                type="number"
                id="eletkor"
                className="form-control"
                min="0"
                max="20"
              />

              <label htmlFor="kep" className="form-label mt-2">
                Fénykép a kutyáról
              </label>
              <input
                ref={inputKep}
                type="text"
                id="kep"
                className="form-control"
              />

              <div className="row text-center mt-4">
                <div className="col">
                  <button className="btn btn-primary" onClick={addNewKutya}>Küldés</button>
                </div>
              </div>

            { errorState &&
              <div className="alert alert-danger mt-5" role="alert">
                {errorState.status + " - " + errorState.statusText}
              </div>
            }
            
          </div>
        </div>
      </main>
    </div>
  );
}
