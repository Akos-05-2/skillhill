import { Link } from "react-router-dom";

export default function Nyitooldal(){
    return (
        <div className="container">
            <header className="text-center">
                <div className="row my-3">
                    <h1>Kutyamenhely</h1>
                </div>
                <div className="row">
                    <div className="col">                        
                        <Link to="/kutyak" className="btn btn-primary">Örökbefogadható kutyák</Link>
                    </div>
                    <div className="col">                        
                        <Link to="/ujkutya" className="btn btn-primary">Új kutya felvétele</Link>
                    </div>
                </div>
            </header>
            <main className="mt-3">
                <div className="row">
                    <p>
                    Alapítványunk 2003. októbere óta működteti a Tappancstanya nevű állatmenhelyét, amely az első 9 évben csak kutyamenhelyként funkcionált.  A tanya eredetileg egy bentlakásos kutyakiképző bázisként funkcionált, így a megvásárláskor már készen kapunk kutyák elhelyezésére alkalmas 28 db. kennelt.
                    </p>
                </div>
                <div className="row">
                    <p className="ps-5">
                        Kutyamenhelyünket a következő elvek alapján működtetjük:
                    </p>
                    <ul className="ms-2 ps-4">
                        <li>Minden befogadott kutyának joga van megfelelő minőségű és mennyiségű ételre, évente a kötelező és ajánlott védőoltásra, rendszeres külső és belső élősködők elleni kezelésre, szívféregkezelésre, betegség esetén minőségi állategészségügyi ellátásra.</li>
                        <li>Minden befogadott kutyának joga van a rendszeres napi mozgásra, ami a hét minden napján, a kenneléhez tartozó úgynevezett "futtatóudvarban" történő 1-3 órás szabad mozgást, futkározást, ásást, labdázást, nyáron medencés fürdőzést jelent. Önkénteseinknek köszönhetően hétvégente pedig pórázon történő sétáltatásra a menhely körül.</li>
                        <li>A befogadott kutyának joga van az élethez. Helyhiány miatt nincs végleges altatás. A befogadott kutyák örökbefogadásukig vagy természetes elmúlásukig biztonságos otthonra számíthatnak a Tappancstanyán.</li>
                        <li>Minden befogadott kutyának joga van a biztonságra. A kutyamenhelyen élő szigorú szabályok mind az ő biztonságukat szolgálják.</li>
                        <li>Minden menhelyi kutyának joga van a megfelelő élettérre. Több kutya az élete jelentős részét egy kutyamenhelyen tölti, joga van a pihenésre, a nyugalomra, joga van olyan más kutyákkal élni egy térben, akikkel egyébként barátság köt.</li>                    
                    </ul>
                    <p>
                        Mindezek miatt a Tappancstanyára csak hosszú várakozás után lehet bejutni. A befogadás sorrendje nem a szigorúan vett jelentkezési sorrend, hanem figyelembe vesszük a várólistára került kutya körülményeit. Mindig a legveszélyeztetettebb körülmények közül emeljük ki a következő befogadott kutyát.
                    </p>
                </div>
            </main>
        </div>
    );
};