import { useEffect, useState } from "react";
import { Kutya } from "../kutya.model";

export default function Kutyak() {
  const [kutyakData, setKutyakData] = useState<Kutya[]>([]);

  const getKutyak = async () => {
    try {
      const result = await fetch("http://localhost:5000/kutyak");
      const data = await result.json();
      //console.log(data);
      setKutyakData(data);
    } catch (error) {
      console.log(error);
    }
  };

  useEffect(() => {
    getKutyak();
  }, []);

  const deleteKutya = async(kutyaId: number) =>{
    try {
        const result = await fetch("http://localhost:5000/kutyak", {
            headers: {
                'Content-Type': 'application/json;charset=UTF-8'
            },
            method: "DELETE",
            body: JSON.stringify({"id": kutyaId})
        });

        // console.log(result);
        if(result.status == 200){
            setKutyakData( kutyakData.filter( kutya => kutya.id != kutyaId) );
        }
        
      } catch (error) {
        console.log(error);
      }
  }

  return (
    <div className="container">
      <header className="text-center">
        <div className="row my-3">
          <h1>Örökbefogadható kutyák</h1>
        </div>
      </header>
      <main>
        <table className="table table-striped">
          <thead>
            <tr>
              <th>Fénykép</th>
              <th>Név</th>
              <th>Fajta</th>
              <th>Nem</th>
              <th>Életkor</th>
              <th>Törlés</th>
            </tr>
          </thead>
          <tbody>
            {kutyakData.map((kutya: Kutya) => {
              return (
                <tr key={kutya.id}>
                  <td>
                    <img src={kutya.kepUrl} alt="" height="100" />{" "}
                  </td>
                  <td>{kutya.nev}</td>
                  <td>{kutya.fajta}</td>
                  <td className={kutya.nem ? "text-success" : "text-danger"}>
                    {kutya.nem ? "Kan" : "Szuka"}
                  </td>
                  <td>{kutya.eletkor}</td>
                  <td>
                    <button className="btn btn-danger" onClick={() => {deleteKutya(kutya.id)} }>Törlés</button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </main>
    </div>
  );
}
