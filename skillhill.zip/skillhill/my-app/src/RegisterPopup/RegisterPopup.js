import React, { useState } from 'react';
import ReactDOM from 'react-dom';
import './RegisterPopup.css';
import { GoogleLogin } from '@react-oauth/google';
import jwt_decode from 'jwt-decode';

const RegisterPopup = ({ onClose }) => {
    return ReactDOM.createPortal(
        <div className="RegisterPopup-overlay">
            <div className="RegisterPopup-content">
                <div id="reg" className="RegisterPopup">
                    <div className="logo">
                        <img src="skill-hill.png" className="logo" width="150px" alt="Skill Hill Logo" />
                    </div>
                    <div>
                        <p className="textheadline">Regisztráljon és kezdjen a tanulásba</p>
                    </div>
                    <div type="submit">
                        <button>Folytassa Google Fiókkal<GoogleLogin
                                onSuccess={credentialResponse => {
                                /*const decode = jwt_decode(credentialResponse?.credential);
                                console.log(credentialResponse);
                                console.log(decode);*/
                                }}
                                onError={() => {
                                console.log('Nem sikerült belépni');
                                }}
                        />;</button> 

                    </div>
                    <label className="container textlight">
                        <input type="checkbox" checked="checked" />
                        <span className="checkmark"></span> Elfogadom az általános szerződési feltételeket.
                    </label>
                    <label className="container textlight">
                        <input type="checkbox" />
                        <span className="checkmark"></span> Szeretnék kapni e-mail értesítéseket.
                    </label>
                    <p className="textlight">Vagy már hozott létre fiókot?</p>
                    <div type="submit">
                        <button>Belépés</button>
                    </div>
                    <div className="whitebox">
                        <p className="textmini">
                            A regisztrációval elfogadja a SkillHill szolgáltatási feltételeit és adatvédelmi szabályzatát.{' '}
                            <a href="gdpr.html">Adatvédelmi Szabályzat</a>, <a href="aszf">ÁSZF</a>,{' '}
                            <a href="cookie">Süti Szabályzat</a>
                        </p>
                    </div>
                    <button className="Registerclose-popup" onClick={onClose}>
                        Bezár
                    </button>
                </div>
            </div>
        </div>,
        document.body
    );
};

export default RegisterPopup;