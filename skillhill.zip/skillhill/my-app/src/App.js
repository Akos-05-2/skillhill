import logo from './pic/skill-hill.png';
import React, { useState } from 'react';
import RegisterPopup from './RegisterPopup/RegisterPopup';
import 'E:/prj/my-app/src/skillhill.css';



function App() {
  const [isPopupOpen, setIsPopupOpen] = useState(false);

  const openPopup = () => setIsPopupOpen(true);
  const closePopup = () => setIsPopupOpen(false)
  return (
    <div className="App">
      <nav>
                <div className="nav">
                    <div className="logo">
                        <a id="brand" href="#">
                            <img src="./pic/skill-hill.png" className="logo" width="150px" alt="Skill Hill Logo" />
                        </a>
                    </div>
                    <div className="registration">
                        <button onClick={openPopup}>Regisztráció</button>
                        
                    </div>
                </div>
            </nav>
            {isPopupOpen && <RegisterPopup onClose={closePopup} />}
    </div>
    
  );
}

export default App;



